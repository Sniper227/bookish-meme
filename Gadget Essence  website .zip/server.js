const express = require("express");
const fetch = require("node-fetch");
const app = express();

app.use(express.json());
app.use(express.static("."));

// Handle order + payment webhook placeholder
app.post("/order", async (req, res) => {
  
  const o = req.body;
  
  // TODO: integrate real payment gateway here
  
  const message =
    `New Gadget Essence Order

Item: ${o.item}
Price: R${o.price}

Customer: ${o.fullname}
Address: ${o.address}

Courier: ${o.courier}
Paxi Store: ${o.paxi_store || "N/A"}

Email: ${o.email}
Phone: ${o.phone}`;
  
  // WhatsApp Report via CallMeBot
  const phone = "0658930004";
  const apiKey = "YOUR_CALLMEBOT_API_KEY";
  
  await fetch(
    `https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${encodeURIComponent(message)}&apikey=${apiKey}`
  ).catch(() => {});
  
  res.json({ status: "ok" });
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));