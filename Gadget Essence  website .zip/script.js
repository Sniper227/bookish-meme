function buyItem(name, price) {
  window.location.href = `checkout.html?item=${encodeURIComponent(name)}&price=${price}`;
}

function toggleCourier(select) {
  const paxi = document.getElementById("paxiField");
  paxi.style.display = select.value === "paxi" ? "block" : "none";
}